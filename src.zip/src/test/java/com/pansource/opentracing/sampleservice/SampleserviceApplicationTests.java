package com.pansource.opentracing.sampleservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

class SampleserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
